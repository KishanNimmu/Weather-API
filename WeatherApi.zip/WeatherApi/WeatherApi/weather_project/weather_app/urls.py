# urls.py
from django.urls import path
from . import views

urlpatterns = [
    # path('', views.login_view, name='login'),
    # path('logout', views.logout_view, name='logout'),
     # Registration URL should come after login

    path('index', views.index, name="index"),
    path('login', views.login, name="login"),
    path('login_page',views.login, name="login_page"),
    path('',views.register_user,name="register_user"),
    path('login_logic',views.login_logic,name="login_logic"),
]
