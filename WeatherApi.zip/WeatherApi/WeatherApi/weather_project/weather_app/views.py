import datetime
import requests
from .models import User
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
import json
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm




# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login







def index(request):
    api_key = '4e3bf8ad4566a68b93ef2dcc2759727f'
    current_weather_url = 'https://api.openweathermap.org/data/2.5/weather?q={}&appid={}'
    forecast_url = 'https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&cnt=5&appid={api_key}'

    if request.method == 'POST':
        city1 = request.POST['city1']
        city2 = request.POST.get('city2', None)

        weather_data1, daily_forecasts1 = fetch_weather_and_forecast(city1, api_key, current_weather_url, forecast_url)

        if city2:
            weather_data2, daily_forecasts2 = fetch_weather_and_forecast(city2, api_key, current_weather_url, forecast_url)
        else:
            weather_data2, daily_forecasts2 = None, None

        context = {
            'weather_data1': weather_data1,
            'daily_forecasts1': daily_forecasts1,
            'weather_data2': weather_data2,
            'daily_forecasts2': daily_forecasts2,
        }

        return render(request, 'index.html', context)
    else:
        return render(request, 'index.html')

def fetch_weather_and_forecast(city, api_key, current_weather_url, forecast_url):
    response = requests.get(current_weather_url.format(city, api_key)).json()
    lat, lon = response['coord']['lat'], response['coord']['lon']
    forecast_response = requests.get(forecast_url.format(lat=lat, lon=lon, api_key=api_key)).json()

    weather_data = {
        'city': city,
        'temperature': round(response['main']['temp'] - 273.15, 2),
        'description': response['weather'][0]['description'],
        'icon': response['weather'][0]['icon'],
    }

    daily_forecasts = []
    for daily_data in forecast_response['list']:
        daily_forecasts.append({
            'day': datetime.datetime.fromtimestamp(daily_data['dt']).strftime('%A'),
            'min_temp': round(daily_data['main']['temp_min'] - 273.15, 2),
            'max_temp': round(daily_data['main']['temp_max'] - 273.15, 2),
            'description': daily_data['weather'][0]['description'],
            'icon': daily_data['weather'][0]['icon'],
        })

    return weather_data, daily_forecasts


def register_user(request):
    if request.method == 'POST':
        #  print(request.POST)
        fullname = request.POST.get('fname')
        email = request.POST.get('umail')
        username = request.POST.get('uname')
        password = request.POST.get('upass')
        mobileno = request.POST.get('mnum')
        location = request.POST.get('address')
        user = User(
            fullname=fullname,
            email=email,
            username=username,
            password=password,
            mobileno=mobileno,
            location=location
        )
        user.save()
        return render(request, 'login.html')
    else:
        return render(request, 'register.html')


def login(request):
    return render(request, 'login.html')


def login_logic(request):
    user = User.objects.all()
    if request.method == "POST":
        uname = request.POST.get('username')
        pwd = request.POST.get('password')
        flag = User.objects.filter(username=uname, password=pwd).values()
        if flag:
            return render(request, 'index.html')
        else:

            return render(request, 'index.html')